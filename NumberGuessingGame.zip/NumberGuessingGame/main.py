import tkinter as tk
from ui import GameUI

if __name__ == "__main__":
    root = tk.Tk()
    game_ui = GameUI(root)
    root.mainloop()
